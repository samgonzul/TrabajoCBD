package enumerados;

public enum PotenciaMax {
	potencia_maxima_p1,potencia_maxima_p2,potencia_maxima_p3,potencia_maxima_p4,
	potencia_maxima_p5,potencia_maxima_p6,potencia_maxima_p7
}
